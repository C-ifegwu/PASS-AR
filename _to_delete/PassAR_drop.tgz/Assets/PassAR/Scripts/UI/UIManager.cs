using System;
using UnityEngine;
using UnityEngine.UI;

namespace PassAR
{
    /// <summary>
    /// Everything the user sees and taps. Contains no simulation logic: it shows
    /// what it is told and raises events when buttons are used.
    /// </summary>
    public class UIManager : MonoBehaviour
    {
        [Header("Panels")]
        [SerializeField] private GameObject welcomePanel;
        [SerializeField] private GameObject permissionPanel;
        [SerializeField] private GameObject hudPanel;
        [SerializeField] private GameObject summaryPanel;
        [SerializeField] private GameObject trackingLostBanner;

        [Header("Welcome / permission")]
        [SerializeField] private Button startButton;
        [SerializeField] private Button retryButton;
        [SerializeField] private Text permissionMessage;
        [SerializeField] private Text busyText;

        [Header("HUD")]
        [SerializeField] private Text instructionText;
        [SerializeField] private Text messageText;
        [SerializeField] private Text timerText;
        [SerializeField] private Button pullPinButton;
        [SerializeField] private HoldButton squeezeButton;
        [SerializeField] private Image squeezeImage;
        [SerializeField] private Button muteButton;
        [SerializeField] private Text muteLabel;
        [SerializeField] private GameObject reticle;
        [SerializeField] private GameObject actionButtons;

        [Header("Summary")]
        [SerializeField] private Text summaryTime;
        [SerializeField] private Text summaryErrors;
        [SerializeField] private Text summaryScore;
        [SerializeField] private Text summaryBest;
        [SerializeField] private Button restartButton;

        public event Action StartPressed;
        public event Action RetryPressed;
        public event Action PullPinPressed;
        public event Action SqueezeDown;
        public event Action SqueezeUp;
        public event Action RestartPressed;
        public event Action MutePressed;

        private static readonly Color WarningColor = new Color(1f, 0.45f, 0.4f);
        private static readonly Color HintColor = new Color(1f, 0.85f, 0.3f);
        private static readonly Color FeedbackColor = new Color(0.55f, 1f, 0.6f);

        private const float WarningSeconds = 2.5f;
        private const float FeedbackSeconds = 1.5f;

        private string hint = "";
        private string transientText = "";
        private Color transientColor;
        private float transientUntil;

        private void Awake()
        {
            startButton.onClick.AddListener(() => StartPressed?.Invoke());
            retryButton.onClick.AddListener(() => RetryPressed?.Invoke());
            pullPinButton.onClick.AddListener(() => PullPinPressed?.Invoke());
            restartButton.onClick.AddListener(() => RestartPressed?.Invoke());
            muteButton.onClick.AddListener(() => MutePressed?.Invoke());
            squeezeButton.Pressed += () => SqueezeDown?.Invoke();
            squeezeButton.Released += () => SqueezeUp?.Invoke();

            ShowOnly(null);
        }

        private void Update()
        {
            // Warnings and feedback win over the hint; the hint stays until cleared.
            if (Time.unscaledTime < transientUntil)
            {
                messageText.text = transientText;
                messageText.color = transientColor;
            }
            else
            {
                messageText.text = hint;
                messageText.color = HintColor;
            }
        }

        // ---- panels ---------------------------------------------------------------

        private void ShowOnly(GameObject panel)
        {
            welcomePanel.SetActive(panel == welcomePanel);
            permissionPanel.SetActive(panel == permissionPanel);
            hudPanel.SetActive(panel == hudPanel);
            summaryPanel.SetActive(false);
        }

        public void ShowWelcome()
        {
            ShowOnly(welcomePanel);
            busyText.text = "";
            startButton.gameObject.SetActive(true);
        }

        public void ShowBusy(string message)
        {
            busyText.text = message;
            startButton.gameObject.SetActive(false);
        }

        public void ShowPermissionDenied(string message = null)
        {
            ShowOnly(permissionPanel);
            permissionMessage.text = message ??
                "Camera access is needed to place the fire in your room. Please allow the camera and try again.";
        }

        public void ShowScanning()
        {
            ShowOnly(hudPanel);
            actionButtons.SetActive(false);
            reticle.SetActive(false);
            timerText.text = "";
            ClearHint();
            ShowInstruction("Move your phone slowly to scan the floor, then TAP a floor surface to place the fire.");
        }

        public void ShowTraining()
        {
            ShowOnly(hudPanel);
            actionButtons.SetActive(true);
            reticle.SetActive(true);
            timerText.text = "0 s";
            SetSqueezeLooksEnabled(false);
        }

        // ---- text -------------------------------------------------------------------

        public void ShowInstruction(string message)
        {
            instructionText.text = message;
        }

        public void ShowWarning(string message)
        {
            SetTransient(message, WarningColor, WarningSeconds);
        }

        public void ShowFeedback(string message)
        {
            SetTransient(message, FeedbackColor, FeedbackSeconds);
        }

        public void ShowHint(string message)
        {
            hint = message;
        }

        public void ClearHint()
        {
            hint = "";
        }

        private void SetTransient(string message, Color color, float seconds)
        {
            transientText = message;
            transientColor = color;
            transientUntil = Time.unscaledTime + seconds;
        }

        public void SetTimer(int seconds)
        {
            timerText.text = seconds + " s";
        }

        public void SetSqueezeLooksEnabled(bool enabled)
        {
            // The button still receives presses when "disabled" so that pressing it
            // too early can be counted as an out-of-order action (FR-07, FR-12).
            squeezeImage.color = enabled ? new Color(0.85f, 0.15f, 0.12f) : new Color(0.35f, 0.35f, 0.35f);
        }

        public void SetMuteLabel(bool muted)
        {
            muteLabel.text = muted ? "Sound: OFF" : "Sound: ON";
        }

        public void ShowTrackingLost(bool lost)
        {
            trackingLostBanner.SetActive(lost);
        }

        // ---- summary ------------------------------------------------------------------

        public void ShowSummary(SessionRecord record, int bestScore)
        {
            summaryPanel.SetActive(true);
            actionButtons.SetActive(false);
            reticle.SetActive(false);

            summaryTime.text = "Time: " + record.durationSec.ToString("0.0") + " s";
            summaryErrors.text = "Errors: " + record.errors;
            summaryScore.text = "Score: " + record.score + " / 100";
            summaryBest.text = bestScore >= 0 ? "Best score: " + bestScore : "";
            ShowInstruction(record.errors == 0
                ? "Well done - fire out with no mistakes."
                : "Fire out. Try again to improve your score.");
        }

        public void HideSummary()
        {
            summaryPanel.SetActive(false);
        }
    }
}
